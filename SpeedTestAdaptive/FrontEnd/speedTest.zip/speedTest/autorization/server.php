<?php
// $validUserName = 'admin';
// $validPassword = '123';
// $userName = $_POST['userName'];
// $password = $_POST['password'];
// $isRight = false;
// if ($userName == $validUserName && $password == $validPassword){
//     $isRight = $validUserName;
// }else{
//     $isRight = 0;
// }
// echo $isRight;


// $db_connect = mysqli_connect('localhost', 'accounts', '', 'accounts');

// $login = $_POST['login'];
// $password = $_POST['password'];
// $name = $_POST['nickName'];
// $rand_index = rand(100000, 999999);

// $w = false;
// if($login.length > 4 and (string($password).length > 8) and $name.length > 4){
//     mysqli_query($db_connect, "INSERT INTO `accounts`(`id`, `login`, `password`, `name`) VALUES ('{$rand_index}','{$login}','{$password}','{$name}')");
//     $w = true;
// }
// echo $w;
session_start();

// $db_connect = mysqli_connect('localhost', 'root', '', 'accounts');

// if (!$db_connect){
//     die("Total Error connecting databse");
// }
// $login = $_POST['input_login'];
// $password = $_POST['input_password'];
// $password_confirm = $_POST['input_repeated_password'];
// $name = $_POST['input_nick'];
// $rand_index = rand(100000, 999999);

// if ($password === $password_confirm){
//     $password = md5($password);
//     mysqli_query($db_connect, "INSERT INTO `accounts` (`id`, `login`, `password`, `name`, `record`) VALUES ('$rand_index', '$login', '$password', '$name', 0)");
//     header('Location: ../autorization/auto.php');
// }
// else{
//     $_SESSION['message'] = 'Пароли не совпадают';
//     header('Location: auto.php');
// }
$connect = mysqli_connect('localhost', 'root', '', 'user');

$login = $_POST['input_login'];
$password = md5($_POST['input_password']);
$check_user = mysqli_query($connect, "SELECT * FROM user WHERE login='$login' AND password='$password'");
if (mysqli_num_rows($check_user) > 0){
    $user = mysqli_fetch_assoc($check_user);
    $_SESSION['user'] = [
        "id" => $user['id'],
        "name" => $user['name'],
        "record" => $user['record'],
        "wpm" => $user['wpm'],
        "acc" => $user['accuracy']
    ];
    $_SESSION['delete'] = 1;
    header('Location: ../speed.php');
} else {
    $_SESSION['message'] = 'Incorrect data';
    header('Location: auto.php');
}

?>
