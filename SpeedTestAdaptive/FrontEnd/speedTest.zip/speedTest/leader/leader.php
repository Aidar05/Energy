<?php
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link rel='stylesheet' type='text/css' media='screen' href='leader.css'>
    <script
        src="https://code.jquery.com/jquery-3.6.3.min.js"
        integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU="
        crossorigin="anonymous">
    </script>
    <script src="user.js"></script>
    <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
</head>
<body style="background-image: url(../noise.png);">
    <header></header>  
    <div class="wrapper">
        <div class="header">
            <div class="header_place">
                <div class="logo"></div>
                <div class="menu">
                    <a href="../speed.php"><div class="menu_punct"><span>Home</span></div></a>
                    <a href="#"><div class="menu_punct"><span>autoriazation</span></div></a>
                    <a href="../registration/auto.php"><div class="menu_punct"></span>registration<span></div></a>
                    <a href="../speed.php"><div class="menu_punct"><span>exit</span></div></a>
                </div>
                <div class="auto">
                    <?php if (isset($_SESSION['user'])) { ?>
                        <?= $_SESSION['user']['name'] ?>
                        <lord-icon
                            src="https://cdn.lordicon.com/bhfjfgqz.json"
                            trigger="hover"
                            colors="primary:#121331"
                            state="hover"
                            style="width:30px;height:250px">
                        </lord-icon>
                        <a class="navigation" href="logout.php">exit</a>
                    <?php } else { ?>
                        <!-- autorization -->
                        <a class="navigation" style="display:none;" href="autorization/auto.php">try</a>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="main">
            <div class="regis" id="main_heading">
                <h2>SpeedType</h2>
                <span style="font-size:20px;letter-spacing: 0.1em;">The fastest ten</span>
            </div>
            <div class="result">
                <?php
                    $conn = mysqli_connect("localhost", "root", "", "user");

                    // Check connection
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                    }

                    $sql = "SELECT * FROM user ORDER BY CAST(record AS UNSIGNED) DESC LIMIT 10";
                    $result = mysqli_query($conn, $sql);

                    $count = 0;
                    if (mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)) {
                            $count++;
                            echo $count . ". ";
                            echo $row["name"] . " ". " - ";
                            echo $row["record"]. " cpm" . " <br>";
                        }
                    } else {
                        echo "No users found.";
                    }

                    mysqli_close($conn);
                    ?>
            </div>
        </div>
        <footer>
            Contact with us<br>
            <a href="https://mail.google.com/mail/u/0/#inbox">hdvdj7257@gmail.com</a>
        </footer>
    </div>
</body>
</html>