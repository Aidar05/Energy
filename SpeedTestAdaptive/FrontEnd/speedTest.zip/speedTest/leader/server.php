<?php
// $validUserName = 'admin';
// $validPassword = '123';
// $userName = $_POST['userName'];
// $password = $_POST['password'];
// $isRight = false;
// if ($userName == $validUserName && $password == $validPassword){
//     $isRight = $validUserName;
// }else{
//     $isRight = 0;
// }
// echo $isRight;


// $db_connect = mysqli_connect('localhost', 'accounts', '', 'accounts');

// $login = $_POST['login'];
// $password = $_POST['password'];
// $name = $_POST['nickName'];
// $rand_index = rand(100000, 999999);

// $w = false;
// if($login.length > 4 and (string($password).length > 8) and $name.length > 4){
//     mysqli_query($db_connect, "INSERT INTO `accounts`(`id`, `login`, `password`, `name`) VALUES ('{$rand_index}','{$login}','{$password}','{$name}')");
//     $w = true;
// }
// echo $w;
session_start();

// $db_connect = mysqli_connect('localhost', 'root', '', 'accounts');

// if (!$db_connect){
//     die("Total Error connecting databse");
// }
// $login = $_POST['input_login'];
// $password = $_POST['input_password'];
// $password_confirm = $_POST['input_repeated_password'];
// $name = $_POST['input_nick'];
// $rand_index = rand(100000, 999999);

// if ($password === $password_confirm){
//     $password = md5($password);
//     mysqli_query($db_connect, "INSERT INTO `accounts` (`id`, `login`, `password`, `name`, `record`) VALUES ('$rand_index', '$login', '$password', '$name', 0)");
//     header('Location: ../autorization/auto.php');
// }
// else{
//     $_SESSION['message'] = 'Пароли не совпадают';
//     header('Location: auto.php');
// }







// $connect = mysqli_connect('localhost', 'root', '', 'user');

// $check_user = mysqli_query($connect, "SELECT * FROM user WHERE login='$login' AND password='$password'");
// if (mysqli_num_rows($check_user) > 0){
//     $user = mysqli_fetch_assoc($check_user);
//     $_SESSION['user']
    
// }

// Подключение к базе данных
// $servername = "localhost";
// $dbname = "user";
// $conn = mysqli_connect($servername, 'root', '', $dbname);

// // Проверка соединения
// if (!$conn) {
//     die("Connection failed: " . mysqli_connect_error());
// }

// // Запрос на выборку из таблицы
// $sql = "SELECT record FROM user ORDER BY record DESC LIMIT 10";
// $result = mysqli_query($conn, $sql);



// // Вывод 10 самых больших значений
// if (mysqli_num_rows($result) > 0) {
//     while($row = mysqli_fetch_assoc($result)) {
//         $sql = "SELECT 'name' FROM user WHERE record =;
//         echo $row["record"]. "<br>";
//     }
// } else {
//     echo "0 results";
// }

// // Закрытие соединения
// mysqli_close($conn);
//

// Подключаемся к базе данных
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "user";

// $conn = new mysqli($servername, $username, $password, $dbname);

// // Проверяем подключение
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// // Выбираем 10 самых больших чисел из базы данных
// $sql = "SELECT record FROM user ORDER BY record DESC LIMIT 10";
// $result = $conn->query($sql);

// // Проверяем результат запроса
// if ($result->num_rows > 0) {
//     // Выводим результат
//     while($row = $result->fetch_assoc()) {
//         echo "Number: " . $row["record"] . "<br>";
//     }
// } else {
//     echo "0 results";
// }

// // Закрываем подключение
// $conn->close();

// Connect to the database

